import pandas as pd
from ibm_watsonx_ai.foundation_models import Model
from ibm_watsonx_ai.foundation_models.utils.enums import ModelTypes
import os
import json

current_dir = os.path.dirname(os.path.abspath(__file__))
final_txt_path = os.path.join(current_dir, "Credentials\Prompt", "Final.txt")
watsonx_cred_txt_path = os.path.join(current_dir, "Credentials", "watsonx_cred.json")


# Load WatsonX credentials
with open(watsonx_cred_txt_path, 'r') as f:
    watsonx_cred = json.load(f)

# Load the prompt for the new task
with open(final_txt_path, 'r') as file:
    prompt_template = file.read()

# Initialize the LLM model
print("Loading LLM Model")
model = Model(
    model_id=ModelTypes.MIXTRAL_8X7B_INSTRUCT_V01,
    params=watsonx_cred['parameters'],
    credentials=watsonx_cred['credentials'],
    project_id=watsonx_cred['project_id'],
    space_id=None
)
print("Loading LLM Model Done.")

file_path = r'Sample Data\test_data.csv'
df= pd.read_csv(file_path)

# Apply data type conversions
df['UpliftDate']=pd.to_datetime(df['UpliftDate'])
df['IssueDate']=pd.to_datetime(df['IssueDate'])

df[df.select_dtypes(['object']).columns] = df.select_dtypes(['object']).apply(lambda x: x.apply(lambda y: y.strip() if isinstance(y, str) else y))



def generate_prompt(query, prompt_template):
    # Replace the placeholder [USER_QUERY] with the actual user query
    new_prompt = prompt_template.replace('[USER_QUERY]', query)
    # print(new_prompt)
    # print('-' * 40)
    # print(new_prompt)
    # print('-' * 40)
    return new_prompt

def perform_llm_call(query):
    global model, prompt_template

    new_prompt = generate_prompt(query, prompt_template)

    print("Calling Model")
    generated_response = model.generate_text(prompt=new_prompt, guardrails=False)
    print("Calling Model Done")
    generated_response = generated_response.replace('<end of code>', '').strip()

    compile_exec = {'df':df}
    try:
        exec(generated_response, compile_exec)
        result_msg, result_data, graph_img = compile_exec['message'], compile_exec['analyzed_df'], compile_exec['graph']
        return result_msg, result_data, graph_img, generated_response
    except Exception as e:
        msg = f"I'm sorry, I encountered an issue while trying to process your question : {str(e)} . Could you please try rephrasing it or provide more context?"
        return msg, None, None, generated_response


