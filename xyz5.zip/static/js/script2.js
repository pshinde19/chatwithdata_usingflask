function getTimestamp() {
    const now = new Date();
    const year = now.getFullYear();
    const month = (now.getMonth() + 1).toString().padStart(2, '0'); // Add leading 0 if necessary
    const day = now.getDate().toString().padStart(2, '0');
    const hours = now.getHours().toString().padStart(2, '0');
    const minutes = now.getMinutes().toString().padStart(2, '0');   
    const seconds = now.getSeconds().toString().padStart(2, '0');
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;    
}

// console.log(getTimestamp());
var sendbtn=document.getElementById('sendbtn')
var chatbox=document.getElementById('chatbox-main-ul')
var textareainp=document.getElementById('textareainp')
var div_counter=0
var table_selected=''

function getanswer(userinput){
    var timestampquery=getTimestamp()
    // console.log( $('#selct-table').val());
    if(userinput != ''){
        getque(userinput)
        var formdata = new FormData();
        formdata.append('que', userinput);
        formdata.append('tablename',table_selected)
        if(table_selected != ''){
            $.ajax({
                type: 'POST',
                url: '/getanswer',
                data: formdata,
                processData: false, // Important for FormData
                contentType: false,
                success: function(response) {
                    console.log(response);
                    document.getElementById('myloader').remove()
                    if(response.msg =='success'){
                        var logdata={
                            "username":"pranay",
                            "timestampquery":timestampquery,
                            "timestampresponse":getTimestamp(),
                            "question":userinput,
                            "response":response.result['response']
                        }
                        getresponse(response.result,logdata)
                    }else if(response.msg =='error'){
                        var lastresp="#bot-response"+ div_counter
                        if(response.error != ''){
                            $(lastresp).append(`<div class="response" style="display:block;">${response.error}</div>` )
                        }
                        div_counter+=1
                    }
                },
                error: function(error) {
                    // Handle error error.statusText
                    console.log(error);
                    document.getElementById('myloader').remove()
                    var lastresp="#bot-response"+ div_counter
                    $(lastresp).append(`<div class="response" style="display:block;color:red;width: 100%;">${error.statusText}</div>` )
                    div_counter+=1
                }
            });
        }else{
            document.getElementById('myloader').remove()
            var lastresp="#bot-response"+ div_counter
            $(lastresp).append(`<div class="response" style="display:block;color:red;width: 100%;">No table selected....</div>` )
            div_counter+=1
        }
       
    }else{
        console.log('empty msg');
        
    }
}

function getque(userinput){
    var htmlstr=`<li class="rightli">
                   <div class="bot-question Pli">
                        <div class="u-question">
                            ${userinput}
                        </div>
                        <div class="botlogodiv">
                            <img src="../static/images/user.png" alt="" srcset="">
                        </div>
                   </div>
                </li>
                <li  class="leftli">
                    <div class="bot-response Pli">
                        <div class="botlogodiv">
                            <img src="../static/images/wizard.png" alt="" srcset="">
                        </div>
                        <div id="myloader" style="display: flex;align-items: center;gap: 2px;margin: auto 0px;"><span class="xloader"></span><span>Loading...</span></div>
                        <div id="bot-response${div_counter}" style="flex: 1 1 90%;width:90%"></div>
                    </div>
                </li>`
    chatbox.insertAdjacentHTML('beforeend', htmlstr);
    textareainp.value=''
    var detailsElements = document.querySelectorAll('details');
    // Loop through each <details> element and remove the "open" attribute
    detailsElements.forEach(function(details) {
        details.removeAttribute('open');
    });
}

function getresponse(data,logdata){ 
    console.log(data);
    var j_logdata=JSON.stringify(logdata)
    var j_logdataStr = JSON.stringify(j_logdata).replace(/"/g, '&quot;').replace(/'/g, "&apos;");
    console.log(j_logdataStr);
    
    var lastresp="#bot-response"+ div_counter
    if(data['response'] != ''){   //width: 90%;
        $(lastresp).append(`<div class="response" style="display:block;">${data['response']}</div>` )
    }
    if(data['new_data'] != ''){
        $(lastresp).append(`
            <details class="details" open>
                <summary class="summary" onclick="togglesvgarrow(this)">
                    <span>Data</span>
                    <svg style="transform: rotatez(180deg);" viewBox="0 0 20 20" aria-hidden="true" focusable="false" fill="currentColor" xmlns="http://www.w3.org/2000/svg" color="inherit" data-testid="stExpanderToggleIcon" class=""><path fill="none" d="M0 0h24v24H0V0z"></path><path d="M12 8l-6 6 1.41 1.41L12 10.83l4.59 4.58L18 14l-6-6z"></path></svg>
                </summary>
                <div class="mydataframe-parent"  style="width: fit-content;">
                <div class="table-utility-parent">
                        <div class="table-utility">
                            <div>
                                <button kind="elementToolbar" class="" onclick="exportTableToExcel(this)">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-download" viewBox="0 0 16 16">
                                    <title>download</title>
                                    <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5"></path>
                                    <path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708z"></path>
                                    </svg>
                                </button>
                            </div>
                            <div>
                                <button kind="elementToolbar" onclick="searchonoff(this)">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                                        <title>search</title>
                                        <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001q.044.06.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1 1 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0"></path>
                                    </svg>
                                </button>
                            </div>
                            <div class="modalopener">
                                <button  kind="elementToolbar" onclick="openmodal(this)" style="display:block;">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-fullscreen" viewBox="0 0 16 16">
                                        <title>fullscreen</title>
                                        <path d="M1.5 1a.5.5 0 0 0-.5.5v4a.5.5 0 0 1-1 0v-4A1.5 1.5 0 0 1 1.5 0h4a.5.5 0 0 1 0 1zM10 .5a.5.5 0 0 1 .5-.5h4A1.5 1.5 0 0 1 16 1.5v4a.5.5 0 0 1-1 0v-4a.5.5 0 0 0-.5-.5h-4a.5.5 0 0 1-.5-.5M.5 10a.5.5 0 0 1 .5.5v4a.5.5 0 0 0 .5.5h4a.5.5 0 0 1 0 1h-4A1.5 1.5 0 0 1 0 14.5v-4a.5.5 0 0 1 .5-.5m15 0a.5.5 0 0 1 .5.5v4a1.5 1.5 0 0 1-1.5 1.5h-4a.5.5 0 0 1 0-1h4a.5.5 0 0 0 .5-.5v-4a.5.5 0 0 1 .5-.5"></path>
                                    </svg>
                                </button>
                            </div>
                        </div>
                        <div class="mysearchutility" style="display: none;">
                            <div>
                                <input type="search" name="" id="" placeholder="Search here..." style="display: block;" oninput="searchtable(this)">
                                <!-- <span>0 results</span> -->
                            </div>
                            <!-- <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16">
                                <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
                              </svg> -->
                        </div>
                </div>
                <div class="mydataframe">
                ${data['new_data']}
                </div>
                </div>
            </details> 
            `)
    }
    if(data['graph_html'] != ''){
       $(lastresp).append(`
        <details class="details" open>
            <summary class="summary" onclick="togglesvgarrow(this)">
                <span>Graph</span>
                <svg style="transform: rotatez(180deg);" viewBox="0 0 20 20" aria-hidden="true" focusable="false" fill="currentColor" xmlns="http://www.w3.org/2000/svg" color="inherit" data-testid="stExpanderToggleIcon" class=""><path fill="none" d="M0 0h24v24H0V0z"></path><path d="M12 8l-6 6 1.41 1.41L12 10.83l4.59 4.58L18 14l-6-6z"></path></svg>
            </summary>
            <div class="last-graph-1" id='last-graph${div_counter}'>
               ${data['graph_html']}
            </div>
        </details>
        `) 
    }
$(lastresp).append(`
    <div class="utilitybtns">
        <div>${getTimestamp()}</div>
        <div class="utility-icons" data-clipboard-text="${data['response']}" onclick="copytext(this)">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-copy" viewBox="0 0 16 16">
            <title>copy</title>  
            <path fill-rule="evenodd" d="M4 2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2zm2-1a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1zM2 5a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1v-1h1v1a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h1v1z"/>
            </svg>
        </div>
        <div class="utility-icons" onclick="positivefeedback(this, ${j_logdataStr})">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-hand-thumbs-up" viewBox="0 0 16 16">
            <title>positive</title>
            <path d="M8.864.046C7.908-.193 7.02.53 6.956 1.466c-.072 1.051-.23 2.016-.428 2.59-.125.36-.479 1.013-1.04 1.639-.557.623-1.282 1.178-2.131 1.41C2.685 7.288 2 7.87 2 8.72v4.001c0 .845.682 1.464 1.448 1.545 1.07.114 1.564.415 2.068.723l.048.03c.272.165.578.348.97.484.397.136.861.217 1.466.217h3.5c.937 0 1.599-.477 1.934-1.064a1.86 1.86 0 0 0 .254-.912c0-.152-.023-.312-.077-.464.201-.263.38-.578.488-.901.11-.33.172-.762.004-1.149.069-.13.12-.269.159-.403.077-.27.113-.568.113-.857 0-.288-.036-.585-.113-.856a2 2 0 0 0-.138-.362 1.9 1.9 0 0 0 .234-1.734c-.206-.592-.682-1.1-1.2-1.272-.847-.282-1.803-.276-2.516-.211a10 10 0 0 0-.443.05 9.4 9.4 0 0 0-.062-4.509A1.38 1.38 0 0 0 9.125.111zM11.5 14.721H8c-.51 0-.863-.069-1.14-.164-.281-.097-.506-.228-.776-.393l-.04-.024c-.555-.339-1.198-.731-2.49-.868-.333-.036-.554-.29-.554-.55V8.72c0-.254.226-.543.62-.65 1.095-.3 1.977-.996 2.614-1.708.635-.71 1.064-1.475 1.238-1.978.243-.7.407-1.768.482-2.85.025-.362.36-.594.667-.518l.262.066c.16.04.258.143.288.255a8.34 8.34 0 0 1-.145 4.725.5.5 0 0 0 .595.644l.003-.001.014-.003.058-.014a9 9 0 0 1 1.036-.157c.663-.06 1.457-.054 2.11.164.175.058.45.3.57.65.107.308.087.67-.266 1.022l-.353.353.353.354c.043.043.105.141.154.315.048.167.075.37.075.581 0 .212-.027.414-.075.582-.05.174-.111.272-.154.315l-.353.353.353.354c.047.047.109.177.005.488a2.2 2.2 0 0 1-.505.805l-.353.353.353.354c.006.005.041.05.041.17a.9.9 0 0 1-.121.416c-.165.288-.503.56-1.066.56z"/>
            </svg>
        </div>
        <div class="utility-icons" onclick="negativefeedback(this, ${j_logdataStr})">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-hand-thumbs-down" viewBox="0 0 16 16">
            <title>negative</title>
            <path d="M8.864 15.674c-.956.24-1.843-.484-1.908-1.42-.072-1.05-.23-2.015-.428-2.59-.125-.36-.479-1.012-1.04-1.638-.557-.624-1.282-1.179-2.131-1.41C2.685 8.432 2 7.85 2 7V3c0-.845.682-1.464 1.448-1.546 1.07-.113 1.564-.415 2.068-.723l.048-.029c.272-.166.578-.349.97-.484C6.931.08 7.395 0 8 0h3.5c.937 0 1.599.478 1.934 1.064.164.287.254.607.254.913 0 .152-.023.312-.077.464.201.262.38.577.488.9.11.33.172.762.004 1.15.069.13.12.268.159.403.077.27.113.567.113.856s-.036.586-.113.856c-.035.12-.08.244-.138.363.394.571.418 1.2.234 1.733-.206.592-.682 1.1-1.2 1.272-.847.283-1.803.276-2.516.211a10 10 0 0 1-.443-.05 9.36 9.36 0 0 1-.062 4.51c-.138.508-.55.848-1.012.964zM11.5 1H8c-.51 0-.863.068-1.14.163-.281.097-.506.229-.776.393l-.04.025c-.555.338-1.198.73-2.49.868-.333.035-.554.29-.554.55V7c0 .255.226.543.62.65 1.095.3 1.977.997 2.614 1.709.635.71 1.064 1.475 1.238 1.977.243.7.407 1.768.482 2.85.025.362.36.595.667.518l.262-.065c.16-.04.258-.144.288-.255a8.34 8.34 0 0 0-.145-4.726.5.5 0 0 1 .595-.643h.003l.014.004.058.013a9 9 0 0 0 1.036.157c.663.06 1.457.054 2.11-.163.175-.059.45-.301.57-.651.107-.308.087-.67-.266-1.021L12.793 7l.353-.354c.043-.042.105-.14.154-.315.048-.167.075-.37.075-.581s-.027-.414-.075-.581c-.05-.174-.111-.273-.154-.315l-.353-.354.353-.354c.047-.047.109-.176.005-.488a2.2 2.2 0 0 0-.505-.804l-.353-.354.353-.354c.006-.005.041-.05.041-.17a.9.9 0 0 0-.121-.415C12.4 1.272 12.063 1 11.5 1"/>
            </svg>    
        </div>
    </div>
`);
    // appendCodeToChatbox(data['generated_response'])
   div_counter+=1
}

function appendCodeToChatbox(code) {
    const chatbox = document.getElementById(`last-code${(div_counter-1)}`);
    const codeElement = document.createElement('pre');
    codeElement.classList.add('language-python'); 
    const codeContent = document.createElement('code');
    codeContent.textContent = code;
    codeElement.appendChild(codeContent);
    chatbox.appendChild(codeElement);
    const button = chatbox.querySelector('button');

    if (button) {
      button.setAttribute('data-clipboard-text', code);
    }
    // Essential step: Highlight the newly added code
    Prism.highlightElement(codeElement);
  }




function copytext(ele){
   console.log(ele.getAttribute('data-clipboard-text'));
   const dataSortValue = ele.getAttribute('data-clipboard-text');
   navigator.clipboard.writeText(dataSortValue)
     .then(() => {
       console.log('Copied to clipboard');
     })
     .catch(err => {
       console.error('Failed to copy: ', err);
     });
}



sendbtn.addEventListener('click',(event)=>{
    event.preventDefault();
    var userinput=textareainp.value.trim()
    getanswer(userinput);
})

textareainp.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' && window.innerWidth > 800 && !event.shiftKey) {
        event.preventDefault(); // Prevent form submission
        var userinput=textareainp.value.trim()
        getanswer(userinput);
    }
});


document.addEventListener('DOMContentLoaded',()=>{
    // $.ajax({
    //     url: "/get_tables", // Replace with your actual API endpoint
    //     type: "POST",
    //     dataType: "json", // Expected data type
    //     data: JSON.stringify({
    //         key1: 'nn',
    //         key2: 'nnn'
    //     }),
    //     contentType: "application/json; charset=utf-8",
    //     success: function(data) {
    //         console.log(data);
    //         if (data.msg === 'success') {
    //             $(".response").append(data.myhtmlstr);
    //             for(let i=0;i<data.my_list.length;i++){
    //               if(i==0){
    //                 $(".current-selected-table").text(data.my_list[i])
    //                 table_selected=data.my_list[i]
    //               }
    //               $(".selecttbl").append(`<li onclick="selecttblfunc('${data.my_list[i]}')"><span class=""> ${data.my_list[i]}</span> </li>`)  
    //             }
    //         }
    //     },
    //     error: function(xhr, status, error) {
    //         console.log(error);
    //     }
    // });
    
})

function selecttblfunc(name){
    $(".current-selected-table").text(name)
    table_selected=name
    // $(".selecttbl").hide()
}

function raw(){
    // <details class="details" open>
    //                         <summary class="summary">
    //                             <span>Code</span>
    //                             <svg style="transform: rotatez(180deg);" viewBox="0 0 20 20" aria-hidden="true" focusable="false" fill="currentColor" xmlns="http://www.w3.org/2000/svg" color="inherit" data-testid="stExpanderToggleIcon" class=""><path fill="none" d="M0 0h24v24H0V0z"></path><path d="M12 8l-6 6 1.41 1.41L12 10.83l4.59 4.58L18 14l-6-6z"></path></svg>
    //                         </summary>
    //                         <div class="clipboard last-code-1" id='last-code${div_counter}' style='position:relative;'>
    //                                 <button  title="Copy to clipboard" data-clipboard-text="" class="copybtn" style="" onclick="copytext(this)">
    //                                     <svg xmlns="http://www.w3.org/2000/svg"
    //                                         width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
    //                                         stroke-linecap="round" stroke-linejoin="round">
    //                                         <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
    //                                         <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
    //                                     </svg>
    //                                 </button>
    //                         </div>
    //                     </details> 
}

function exportTableToExcel(element) {
  //  var tableId='table1'
    // Get the table element
   var tableId= element.parentElement.parentElement.parentElement.nextElementSibling.querySelector('table').id;
    const table = document.getElementById(tableId);
    
  
    // Initialize CSV content
    var csvContent = "";
            
    // Loop through each row
    for (var i = 0; i < table.rows.length; i++) {
        var row = table.rows[i];
        var rowData = [];

        // Loop through each cell in the row
        for (var j = 0; j < row.cells.length; j++) {
             if( j!=0){
                rowData.push(row.cells[j].innerText);
             }
            
        }

        // Join row data with commas and add a new line
        csvContent += rowData.join(",") + "\n";
    }

    // Create a Blob from the CSV content
    var blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    
    // Create a link element
    var link = document.createElement("a");
    if (link.download !== undefined) {
        // Set the file name
        link.setAttribute("href", URL.createObjectURL(blob));
        link.setAttribute("download", "download.csv");

        // Trigger the download by clicking the link
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
  }

function openmodal(element){
  $(".mymodal").show()
  var masterdata= element.parentElement.parentElement.parentElement.parentElement
  var masterdataHTML = masterdata.innerHTML;
 
  var tempElement = document.createElement('div');
  tempElement.classList.add('mydataframe-parent');
  tempElement.style.width = 'fit-content';
  tempElement.innerHTML = masterdataHTML;

   var utilityElements = tempElement.querySelectorAll('.modalopener')[0]
    utilityElements.innerHTML=`<button onclick="closemodal(this)">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-fullscreen-exit" viewBox="0 0 16 16">
                                        <path d="M5.5 0a.5.5 0 0 1 .5.5v4A1.5 1.5 0 0 1 4.5 6h-4a.5.5 0 0 1 0-1h4a.5.5 0 0 0 .5-.5v-4a.5.5 0 0 1 .5-.5m5 0a.5.5 0 0 1 .5.5v4a.5.5 0 0 0 .5.5h4a.5.5 0 0 1 0 1h-4A1.5 1.5 0 0 1 10 4.5v-4a.5.5 0 0 1 .5-.5M0 10.5a.5.5 0 0 1 .5-.5h4A1.5 1.5 0 0 1 6 11.5v4a.5.5 0 0 1-1 0v-4a.5.5 0 0 0-.5-.5h-4a.5.5 0 0 1-.5-.5m10 1a1.5 1.5 0 0 1 1.5-1.5h4a.5.5 0 0 1 0 1h-4a.5.5 0 0 0-.5.5v4a.5.5 0 0 1-1 0z"/>
                                    </svg>
                                </button>`;
  $('.mymodal-content').html(tempElement)
  
}

function closemodal(element){
    $(".mymodal").hide()
}

function searchtable(element){
    console.log('called');
    
    var table= element.parentElement.parentElement.parentElement.nextElementSibling.querySelector('table');
    var searchValue=element.value.toLowerCase();
    var rows = table.querySelectorAll('tr');
    // var  spanresults=element.nextElementSibling
    var count=0
    // Loop through each row
    rows.forEach(function(row, index) {
        if (index === 0) return; // Skip the first row (header)
        // Assume initially that the row does not match the search
        var rowMatches = false;
        // Loop through each cell in the row
        var cells = row.querySelectorAll('td');
        cells.forEach(function(cell) {
            // Check if the cell value matches the search value
            var cellValue = cell.textContent.toLowerCase() || cell.innerText.toLowerCase();
            if (cellValue.includes(searchValue)) {
                rowMatches = true; 
            }
        });
        // Show or hide the row based on whether it matches the search value
        if (rowMatches) {
            row.style.display = ''; // Show the row
            count++;
        } else {
            row.style.display = 'none'; // Hide the row
            count--
        }

    })
    console.log(searchValue,count);

    // spanresults.innerHTML=count + "results"
}


function searchonoff(element){
    var searchtab= element.parentElement.parentElement.nextElementSibling;
    if (searchtab.style.display === 'none' || searchtab.style.display === '') {
        searchtab.style.display = 'block'; // Show the element
    } else {
        searchtab.style.display = 'none'; // Hide the element
    }
}

function togglesvgarrow(element) { 
    const svg = element.querySelector('svg');
   // console.log(svg);
    
    const currentRotation = svg.style.transform;
    if (currentRotation === 'rotateZ(180deg)') {
        svg.style.transform = 'rotateZ(360deg)';
    } else {
        svg.style.transform = 'rotateZ(180deg)';
    }
}

function refreshchat(){
    const chatboxMainUl = document.getElementById('chatbox-main-ul');
    if (chatboxMainUl) {
      const firstLi = chatboxMainUl.firstElementChild;
      if (firstLi) {
        const clonedLi = firstLi.cloneNode(true); // Create a deep clone
        chatboxMainUl.innerHTML = ''; // Clear the contents of the chatbox
        chatboxMainUl.appendChild(clonedLi);
      } else {
        console.error("No first li element found.");
      }
    } else {
      console.error("chatbox-main-ul element not found.");
    }
}

function positivefeedback(ele,data){
    console.log((JSON.parse(data)));
     $.ajax({
        url: '/likeresponse',  // Flask route URL
        type: 'POST',
        contentType: 'application/json',  // Send data as JSON
        data: JSON.stringify(data),  // Convert the object to a JSON string
        success: function(response) {
            console.log('Server response:', response);
            // Handle success response here (e.g., show a notification to the user)
        },
        error: function(xhr, status, error) {
            console.log('Error:', error);
            // Handle error here
        }
    });
}

function negativefeedback(ele,data){
console.log((JSON.parse(data)));
    $.ajax({
        url: '/dislikeresponse',  // Flask route URL
        type: 'POST',
        contentType: 'application/json',  // Send data as JSON
        data: JSON.stringify(data),  // Convert the object to a JSON string
        success: function(response) {
            console.log('Server response:', response);
            // Handle success response here (e.g., show a notification to the user)
        },
        error: function(xhr, status, error) {
            console.log('Error:', error);
            // Handle error here
        }
    });
}


function showsopguide(){
    const element = document.getElementById('sopsection-parent');
    
    if (element.style.height === '93vh') {
        element.style.height = '0vh';
    } else {
        element.style.height = '93vh';
    }
}


$("#selct-table").on('change',()=>{
   // console.log($("#selct-table").val());
    $('.selected-tbl-name').text($("#selct-table").val())
})


function closesopmodal(){
    $("#sopsection-parent ").hide()
}

function opensopguidemodal(){
    $("#sopsection-parent ").show()
}


function clickcards(element) {
    const questionText = element.querySelector('.card-question').textContent.trim();
    console.log(questionText);
    if(questionText != ''){
        $("#sopsection-parent").hide()
        getanswer(questionText);
    }
}