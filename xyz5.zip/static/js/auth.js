const msalConfig = {
    auth: {
        clientId: 'eed1ccf8-2fbc-4a80-a550-cf310dd46e46',
        authority: 'https://login.microsoftonline.com/b49816e8-d18d-4ab0-8878-3ac2f3baf1c3',
        redirectUri: 'http://localhost:5000/',
    }
    ,
    cache: {
        cacheLocation: 'localStorage', // Configures cache location to localStorage
    //    storeAuthStateInCookie: false, // Set to true for IE 11 or Edge
    }
};

const loginRequest = {
    scopes: ["user.read"]
};

const msalInstance = new msal.PublicClientApplication(msalConfig);

async function checkIfUserIsLoggedIn() {
    console.log('popup running');
    try {
        const msalInstance1 = new msal.PublicClientApplication(msalConfig);
        const account = msalInstance1.getAllAccounts()[0];
        if (account) {
          const accessToken = await msalInstance1.acquireTokenSilent({
            account: account,
            scopes: ['openid', 'profile', 'email'],
          });
          user_data=accessToken
          console.log('User is logged in:', accessToken);
          return true
        } else {
          console.log('User is not logged in');
           try {
            // Specify the scopes/permissions your app needs
            const request = {
                scopes: ['openid', 'profile', 'email'],
            };
            // Initiate login process
            const loginResponse = await msalInstance.loginRedirect(loginRequest);
            console.log('Login successful:', loginResponse);
            return true
            } catch (error) {
                console.error('Login failed:', error);
                return false
            }
        }
      } catch (error) {
        console.error('Error checking login status:', error);
        return false
      }
  }

$(document).ready(function() {
//   console.log('ready function in index  is running');
    //checkIfUserIsLoggedIn()
});


